package com.yann.basic.socket.yann.basic.socket.io.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class BasicRestController {

    @GetMapping("/api/v1/healthcheck")
    public BaseResponse getMethodName() {
        BaseResponse response = new BaseResponse();
        response.setMessage("OK");
        return response;
    }
    
}

class BaseResponse {
    public static final int RETURN_CODE_200 = 200;
    private int code = RETURN_CODE_200;
    private String message;
    private Object data;
    private String errorMsg;
  
    public BaseResponse(int code, String message,Object obj) {
      this.code = code;
      this.message = message;
      this.data = obj;
    }
    
    public BaseResponse(int code,String errorMsg) {
        this.code = code;
        this.errorMsg = errorMsg;
    }
  
    public BaseResponse() {
    }
  
    public String getMessage() {
      return message;
    }
  
    public void setMessage(String message) {
      this.message = message;
    }
  
      public Object getData() {
          return data;
      }
  
      public void setData(Object data) {
          this.data = data;
      }
  
      public int getCode() {
          return code;
      }
  
      public void setCode(int code) {
          this.code = code;
      }
  
      public String getErrorMsg() {
          return errorMsg;
      }
  
      public void setErrorMsg(String errorMsg) {
          this.errorMsg = errorMsg;
      }
  
  
  }
