package com.yann.basic.socket.yann.basic.socket.io;

import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.corundumstudio.socketio.AuthorizationListener;
import com.corundumstudio.socketio.AuthorizationResult;
import com.corundumstudio.socketio.Configuration;
import com.corundumstudio.socketio.HandshakeData;
import com.corundumstudio.socketio.SocketIOClient;
import com.corundumstudio.socketio.SocketIOServer;
import com.corundumstudio.socketio.annotation.SpringAnnotationScanner;
import com.corundumstudio.socketio.listener.ExceptionListener;

import io.netty.channel.ChannelHandlerContext;

@SpringBootApplication
public class App {
	@Value("${wss.server.host}")
	private String host;
	@Value("${wss.server.port}")
	private Integer port;
	@Value("${ping.interval.milliseconds}")
	private Integer milliSecond;

	@Bean
	public SocketIOServer socketIOServer() {
		Configuration config = new Configuration();
		config.setHostname(host);
		config.setPort(port);
		config.setPingInterval(milliSecond);
		config.setPingTimeout(milliSecond*2);
		config.setUpgradeTimeout(milliSecond*2);
		config.setExceptionListener(new ExceptionListener(){

			@Override
			public void onEventException(Exception e, List<Object> args, SocketIOClient client) {
				System.out.println("onEventException"+e.getMessage());
			}

			@Override
			public void onDisconnectException(Exception e, SocketIOClient client) {
				System.out.println("onDisconnectException"+e.getMessage());
			}

			@Override
			public void onConnectException(Exception e, SocketIOClient client) {
				System.out.println("onConnectException"+e.getMessage());
			}

			@Override
			public void onPingException(Exception e, SocketIOClient client) {
				System.out.println("onPingException"+e.getMessage());
			}

			@Override
			public void onPongException(Exception e, SocketIOClient client) {
				System.out.println("onPongException"+e.getMessage());
			}

			@Override
			public boolean exceptionCaught(ChannelHandlerContext ctx, Throwable e) throws Exception {
				System.out.println("exceptionCaught");
				return false;
			}

			@Override
			public void onAuthException(Throwable e, SocketIOClient client) {
				System.out.println("onAuthException");
			}
			
		});
		config.setAuthorizationListener(new AuthorizationListener(){
			@Override
			public AuthorizationResult getAuthorizationResult(HandshakeData data) {
				AuthorizationResult r = new AuthorizationResult(true);
				return r;
			}
			
		});
		// config.setExceptionListener(new ExceptionListener() {
		// 	@Override
		// 	public void onEventException(Exception e, List<Object> args, SocketIOClient client) {
		// 		System.out.println("onEventException");
		// 		System.out.println(e);
		// 		throw new UnsupportedOperationException("Unimplemented method 'onEventException'");
		// 	}

		// 	@Override
		// 	public void onDisconnectException(Exception e, SocketIOClient client) {
		// 		System.out.println("onDisconnectException ");
		// 		if(client !=null){
		// 			System.out.println(client);
		// 		}
		// 		// throw new UnsupportedOperationException("Unimplemented method 'onDisconnectException'");
		// 		if (client != null && client.isChannelOpen()) {
		// 			client.disconnect();
		// 		}
		// 	}

		// 	@Override
		// 	public void onConnectException(Exception e, SocketIOClient client) {
		// 		System.out.println("onConnectException");
		// 		System.out.println(e);
		// 		// if(e instanceof SocketIOException){
		// 		// 	if(client !=null){
		// 		// 		System.out.println(client);
		// 		// 	}
		// 		// 	// throw new UnsupportedOperationException("Unimplemented method 'onDisconnectException'");
		// 		// 	if (client != null && client.isChannelOpen()) {
		// 		// 		client.disconnect();
		// 		// 	}
		// 		// }
		// 	}

		// 	@Override
		// 	public boolean exceptionCaught(ChannelHandlerContext ctx, Throwable e) throws Exception {
		// 		System.out.println("exceptionCaught");
		// 		System.out.println(e);
		// 		throw new UnsupportedOperationException("Unimplemented method 'exceptionCaught'");
		// 	}
		// });
		// //该处可以用来进行身份验证
		// config.setAuthorizationListener(new AuthorizationListener() {
		// 	@Override
		// 	public boolean isAuthorized(HandshakeData data) {
		// 		//http://localhost:8081?username=test&password=test
		// 		//例如果使用上面的链接进行connect，可以使用如下代码获取用户密码信息，本文不做身份验证
		// 		// String username = data.getSingleUrlParam("username");
		// 		// String password = data.getSingleUrlParam("password");
		// 		return true;
		// 	}
		// });
		final SocketIOServer server = new SocketIOServer(config);
		return server;
	}

	@Bean
	public SpringAnnotationScanner springAnnotationScanner(SocketIOServer socketServer) {
		return new SpringAnnotationScanner(socketServer);
	}

	public static void main(String[] args) {
		SpringApplication.run(App.class, args);
	}
}
