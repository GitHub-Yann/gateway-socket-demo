package com.yann.basic.socket.yann.basic.socket.io.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class BasicController {

    @Value("${host.address}")
    private String hostAddress;

    @GetMapping("index")
    public String forwardMain(Model model) {
        model.addAttribute("hostAddress", hostAddress);
        return "index";
    }
}
