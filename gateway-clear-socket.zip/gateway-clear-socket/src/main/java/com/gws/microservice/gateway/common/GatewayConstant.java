package com.gws.microservice.gateway.common;

/**
 * please follow the name definition
 * 
 * @author yann.chen
 *
 */
public interface GatewayConstant {
	int NUMBER_503=503;
}
