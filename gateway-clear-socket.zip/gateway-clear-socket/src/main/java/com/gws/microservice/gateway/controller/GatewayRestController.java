package com.gws.microservice.gateway.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gws.microservice.gateway.common.BaseResponse;
import com.gws.microservice.gateway.common.GatewayConstant;

@RestController
public class GatewayRestController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(GatewayRestController.class);

	@Value("${project.version}")
	private String projectVersion;

	@GetMapping("gateway/healthcheck")
	public BaseResponse healthCheck() {
		BaseResponse response = new BaseResponse();
		response.setMessage("Gateway[" + projectVersion + "] is alive.");
		return response;
	}

	@GetMapping("gateway/timeout")
	public BaseResponse timeout() {
		BaseResponse response = new BaseResponse();
		response.setCode(GatewayConstant.NUMBER_503);
		response.setMessage("Sorry, the downstream system is unavailable.");
		return response;
	}

}
